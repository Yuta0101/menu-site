# QR-Menu-for-Restaurants
Hi one more time!

This is project that useable for orders of costumers in restaurant or cafe etc.
-That is usefull for scan QR on phone, and see these pages.
-Created JSON and reached to use on page.
-Used mostly JavaScript, contains HTML,CSS as well.
-Whole products created by ChatGPT.

To be honest, This is the most satisficted project for me that I did all the time
I like so much, I hope you like it.

See you soon.
Best Regards...

![qr-menu](https://github.com/evliyademiray/QR-Menu-for-Restaurants/assets/139562305/881cad6d-8d85-4292-bfaa-ecb1813a1d1a)
