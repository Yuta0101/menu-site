//Ekrana basılacak butonların verisi
export const buttonData = [
  {
    id: 1,
    text: "套餐（飲料可更換）",
    value: "套餐",
  },
  {
    id: 2,
    text: "飯麵",
    value: "飯麵",
  },
  {
    id: 3,
    text: "蛋餅 蔥抓餅",
    value: "蛋餅 蔥抓餅",
  },
  {
    id: 4,
    text: "手工饅頭",
    value: "手工饅頭",
  },
    {
    id: 5,
    text: "其他",
    value: "其他",
  },
    {
    id: 6,
    text: "飲料",
    value: "飲料",
  },

];
